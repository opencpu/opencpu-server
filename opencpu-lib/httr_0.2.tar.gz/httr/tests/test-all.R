library(testthat)
test_package("httr")
