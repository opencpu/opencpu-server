library(testthat)
library(evaluate)

test_package("evaluate")
