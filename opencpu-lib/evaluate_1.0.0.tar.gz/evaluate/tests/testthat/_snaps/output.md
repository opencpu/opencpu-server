# handles various numbers of arguments

    Code
      new_source("x", quote(x), f3)
    Condition
      Error in `new_source()`:
      ! Source output handler must have one or two arguments

