#' @method print json
#' @export
print.json <- function(x, ...){
  cat(x)
}
