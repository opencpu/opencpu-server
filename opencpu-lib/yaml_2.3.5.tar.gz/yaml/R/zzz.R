.onUnload <- function(libpath) {
  library.dynam.unload("yaml", libpath)
}
