# infer_type() default method errors for unknown classes

    Can't infer Arrow data type from object inheriting from class_not_supported

---

    Can't infer Arrow data type from object inheriting from class_not_supported

