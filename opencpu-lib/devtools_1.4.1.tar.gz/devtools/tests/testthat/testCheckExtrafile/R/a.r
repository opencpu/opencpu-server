#' A number.
#' @export
a <- 1
