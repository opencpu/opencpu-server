#pragma once

#include <vector>
#include <cstdint>

std::vector<int> get_bidi_embeddings(const std::vector<uint32_t>& string, int& direction);
