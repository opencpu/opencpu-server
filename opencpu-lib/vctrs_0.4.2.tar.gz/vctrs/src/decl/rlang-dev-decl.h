const char* r_friendly_type_of_opts(r_obj* x,
                                    bool value,
                                    bool length);
