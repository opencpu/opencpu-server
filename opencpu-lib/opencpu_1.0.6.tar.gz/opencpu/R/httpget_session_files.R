httpget_session_files <- function(filepath, requri){
  httpget_file(c(filepath, requri));  
}