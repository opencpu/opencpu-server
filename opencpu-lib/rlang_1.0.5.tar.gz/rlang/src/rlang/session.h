#ifndef RLANG_SESSION_H
#define RLANG_SESSION_H


bool r_is_installed(const char* pkg);
bool r_has_colour();
r_obj* r_getppid();


#endif
