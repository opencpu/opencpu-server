#' @keywords internal
"_PACKAGE"

the <- new.env(parent = emptyenv())

## usethis namespace: start
## usethis namespace: end
NULL
