library(testthat)

test_check("unix")
