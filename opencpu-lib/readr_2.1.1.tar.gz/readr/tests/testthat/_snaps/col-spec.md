# print(col_spec) with colors

    cols(
      a = [32mcol_double()[39m,
      b = [32mcol_integer()[39m,
      c = [33mcol_logical()[39m,
      d = [31mcol_character()[39m,
      e = [34mcol_date(format = "")[39m,
      f = [34mcol_datetime(format = "")[39m,
      g = [34mcol_time(format = "")[39m,
      h = [31mcol_factor(levels = NULL, ordered = FALSE, include_na = FALSE)[39m,
      i = col_skip()
    )

