pre_test_options <- options(
  readr.show_col_types = FALSE,
  readr.show_progress = FALSE
)
