# smoke test

    Code
      pillar(vctrs::unspecified(3), width = 10)
    Output
      <pillar>
           <???>
               .
               .
               .

