stopifnot(
  mime::guess_type('Makefile', empty = 'text/x-makefile') == 'text/x-makefile'
)
