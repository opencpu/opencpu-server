# symlinks

    Code
      zip_list(zf)$type
    Output
      [1] "directory" "file"      "symlink"  

