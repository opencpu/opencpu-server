# inflate

    Code
      inflate(data_gz, 10L, 300L)
    Condition
      Error in `inflate()`:
      ! Input data is invalid

# deflate

    Code
      rawToChar(data$output)
    Output
      [1] "Hello world!"

