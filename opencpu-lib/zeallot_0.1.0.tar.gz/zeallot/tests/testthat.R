library(testthat)
library(zeallot)

test_check("zeallot")
