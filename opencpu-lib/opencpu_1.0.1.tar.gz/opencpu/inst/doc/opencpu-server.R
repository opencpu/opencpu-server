### R code from vignette source 'opencpu-server.Rnw'

