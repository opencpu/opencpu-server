obj_maybe_translate_encoding <- function(x) {
  .Call(vctrs_maybe_translate_encoding, x)
}

obj_maybe_translate_encoding2 <- function(x, y) {
  .Call(vctrs_maybe_translate_encoding2, x, y)
}
