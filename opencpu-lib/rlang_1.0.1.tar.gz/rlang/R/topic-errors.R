# Notes -------------------------------------------------------------------

#' `r title("topic_condition_formatting")`
#'
#' ```{r, child = "man/rmd/topic-condition-formatting.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-condition-formatting
NULL

#' `r title("topic_condition_customisation")`
#'
#' ```{r, child = "man/rmd/topic-condition-customisation.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-condition-customisation
NULL
