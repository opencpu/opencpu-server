static
r_obj* env_clone_roundtrip(r_obj* env, r_obj* parent);

static
r_obj* exists_call;

static
r_obj* remove_call;
