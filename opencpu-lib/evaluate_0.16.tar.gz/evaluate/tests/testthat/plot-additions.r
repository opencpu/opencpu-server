plot(1:10)
lines(1:10)
