context("Initialize")

is_testing(set = TRUE)
