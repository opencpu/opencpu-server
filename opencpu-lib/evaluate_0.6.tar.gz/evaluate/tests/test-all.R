library(testthat)
library(evaluate)

if (getRversion() >= "3.0.2") test_check("evaluate")
