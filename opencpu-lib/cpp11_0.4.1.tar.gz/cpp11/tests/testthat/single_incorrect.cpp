[[cpp11::registe]] int foo() { return 1; }
