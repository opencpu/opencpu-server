library(testthat)
library(readr)

local_edition(1)
test_check("readr")
