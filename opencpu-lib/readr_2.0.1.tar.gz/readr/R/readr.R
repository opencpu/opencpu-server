#' @keywords internal
#' @importFrom hms hms
#' @importFrom R6 R6Class
"_PACKAGE"

## usethis namespace: start
#' @importFrom lifecycle deprecated is_present deprecate_warn deprecate_soft
## usethis namespace: end
NULL
