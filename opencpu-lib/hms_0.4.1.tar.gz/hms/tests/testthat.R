library(testthat)
library(hms)

test_check("hms")
