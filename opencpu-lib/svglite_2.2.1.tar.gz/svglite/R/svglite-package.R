#' @keywords internal
#' @aliases svglite-package
"_PACKAGE"

## usethis namespace: start
#' @importFrom lifecycle deprecated
#' @import rlang
#' @importFrom textshaping text_width
## usethis namespace: end
NULL
