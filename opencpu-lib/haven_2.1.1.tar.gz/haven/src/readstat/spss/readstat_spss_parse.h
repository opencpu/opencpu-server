
readstat_error_t spss_parse_format(const char *data, int count, spss_format_t *fmt);
