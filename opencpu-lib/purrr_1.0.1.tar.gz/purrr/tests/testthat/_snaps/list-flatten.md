# requires a list

    Code
      list_flatten(1:2)
    Condition
      Error in `list_flatten()`:
      ! `x` must be a list, not an integer vector.

