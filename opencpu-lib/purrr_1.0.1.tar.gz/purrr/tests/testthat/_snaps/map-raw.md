# _raw funtions are deprecated

    Code
      . <- map_raw(list(), ~.x)
    Condition
      Warning:
      `map_raw()` was deprecated in purrr 1.0.0.
      i Please use `map_vec()` instead.
    Code
      . <- map2_raw(list(), list(), ~.x)
    Condition
      Warning:
      `map2_raw()` was deprecated in purrr 1.0.0.
      i Please use `map2_vec()` instead.
    Code
      . <- imap_raw(list(), ~.x)
    Condition
      Warning:
      `imap_raw()` was deprecated in purrr 1.0.0.
      i Please use `imap_vec()` instead.
    Code
      . <- pmap_raw(list(), ~.x)
    Condition
      Warning:
      `pmap_raw()` was deprecated in purrr 1.0.0.
      i Please use `pmap_vec()` instead.
    Code
      . <- flatten_raw(list())
    Condition
      Warning:
      `flatten_raw()` was deprecated in purrr 1.0.0.

