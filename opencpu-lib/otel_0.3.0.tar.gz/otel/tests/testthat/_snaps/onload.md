# otel_save_cache, otel_restore_cache

    Code
      as.list(env)
    Output
      $instruments
      NULL
      
      $meter_provider
       [1]  1  2  3  4  5  6  7  8  9 10
      
      $tracer_provider
      [1] "bar"
      
      $logger_provider
      NULL
      
      $otel_tracer
      NULL
      
      $tracer_app
      NULL
      

---

    Code
      as.list(the)
    Output
      $instruments
      NULL
      
      $meter_provider
       [1]  1  2  3  4  5  6  7  8  9 10
      
      $tracer_provider
      [1] "bar"
      
      $logger_provider
      NULL
      
      $otel_tracer
      NULL
      
      $mode
      [1] "prod"
      
      $tracer_app
      NULL
      

# setup_r_trace

    Code
      res
    Output
      [[1]]
      [1] "ok"
      
      [[2]]
      NULL
      
      [[3]]
      NULL
      

---

    Code
      res
    Output
      [[1]]
      [1] "ok"
      
      [[2]]
      [1] "inc*"
      
      [[3]]
      [1] "exclude.*"
      

---

    Code
      res[[1]]
    Output
      [1] "UserHook::ok::onLoad"
    Code
      body(res[[2]])
    Output
      trace_namespace(pkg, inc, exc)

# check_otelsdk_version

    Code
      check_otelsdk_version()
    Message
      otelsdk 0.2.4 is loaded. These otel features need otelsdk 0.2.4.9005 or later:
      * the `set_attributes()` method of spans
      * the `boundaries` argument of `create_histogram()`
      * length one array attributes
      * keeping the `unset` status of automatically ended spans
      * the 'otlp/stdout' exporter
      Update otelsdk to use them.

---

    Code
      check_otelsdk_version()
    Condition
      Warning:
      otel needs otelsdk 0.2.4 or later, but otelsdk 0.2.3 is loaded. Please update otelsdk.

# setup_otelsdk_check

    Code
      body(res[[2]])
    Output
      check_otelsdk_version()

