
## ----insert-fun, echo=FALSE----------------------------------------------
library(knitr)
opts_chunk$set(eval=FALSE)


## ------------------------------------------------------------------------
library(devtools)
install_github("gitstats", "opencpu")


## ------------------------------------------------------------------------
install.packages("opencpu")


## ------------------------------------------------------------------------
library(opencpu)


## ------------------------------------------------------------------------
install_github("gitstats", "opencpu")
opencpu$browse("library/gitstats/www")


## ------------------------------------------------------------------------
install.packages("ggplot2")
install.packages("glmnet")

library(devtools)
install_github("dplyr", "hadley")


