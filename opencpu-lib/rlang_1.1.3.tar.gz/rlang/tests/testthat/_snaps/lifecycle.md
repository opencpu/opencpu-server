# can supply bullets

    Code
      deprecate_warn(c("foo", i = "bar"))
    Condition
      Warning:
      foo
      i bar
      This warning is displayed once every 8 hours.

