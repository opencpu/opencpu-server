#ifndef TIMEGM_H
#define TIMEGM_H

#include <time.h>

time_t timegm2(struct tm *tm);

#endif
