static
enum vctrs_type2_s3 vec_typeof2_s3_impl2(SEXP x,
                                         SEXP y,
                                         enum vctrs_type type_y,
                                         int* left);
