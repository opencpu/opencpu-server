# array_branch throws an error for wrong margins on a vector

    Code
      array_branch(1:3, 2)
    Condition
      Error in `array_branch()`:
      ! `margin` must be `NULL` or `1` with 1D arrays, not "2".

