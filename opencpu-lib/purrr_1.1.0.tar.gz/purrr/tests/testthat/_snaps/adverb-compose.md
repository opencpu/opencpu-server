# composed function prints informatively

    Code
      # Single input
      compose(fn1)
    Output
      <composed>
      1. function(x) x + 1
    Code
      # Multiple inputs
      compose(fn1, fn2)
    Output
      <composed>
      1. function(x) x / 1
      
      2. function(x) x + 1

