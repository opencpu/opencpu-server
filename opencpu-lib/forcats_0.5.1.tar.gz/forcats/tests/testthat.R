library(testthat)
library(forcats)

test_check("forcats")
