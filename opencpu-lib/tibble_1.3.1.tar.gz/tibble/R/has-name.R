#' @inherit rlang::has_name
#' @export
has_name <- function(x, name) rlang::has_name(x, name)
