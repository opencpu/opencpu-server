#ifndef RLANG_INTERNAL_ARG_H
#define RLANG_INTERNAL_ARG_H


int arg_match(r_obj* arg,
              r_obj* values,
              r_obj* error_arg,
              r_obj* error_call);


#endif
