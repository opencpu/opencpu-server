static
bool list_match(r_obj* const * v_x,
                r_ssize n,
                r_obj* value,
                enum option_bool match);
