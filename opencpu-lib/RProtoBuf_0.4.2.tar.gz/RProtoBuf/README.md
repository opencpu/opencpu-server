## RProtoBuf

[![Build Status](https://travis-ci.org/eddelbuettel/rprotobuf.png)](https://travis-ci.org/eddelbuettel/rprotobuf)

R Interface to [Google Protocol Buffers](https://developers.google.com/protocol-buffers/)

## Installation

You can either install from source via this repo, or install
[the CRAN package](http://cran.r-project.org/web/packages/RProtoBuf/index.html)
the usual way from [R](http://www.r-project.org).

## Authors

Romain Francois, Dirk Eddelbuettel, Murray Stokely and Jeroen Ooms

## License

GPL-2


