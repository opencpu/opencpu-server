aa_is_enabled <- function(){FALSE}
stub  <- function(...){stop('RAppArmor was built without apparmor support.')}
aa_find_mountpoint <- stub
aa_find_mountpoint <- stub
aa_getcon <- stub
aa_revert_hat <-  stub
aa_change_hat <- stub
aa_change_profile <- stub
