OpenCPU
=======

The (revised) OpenCPU package. Documentation lacks a bit with software (as usual); most up to date instructions are: http://jeroenooms.github.io/opencpu-manual/opencpu-manual.pdf


