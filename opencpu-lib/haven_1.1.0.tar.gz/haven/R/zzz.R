.onUnload <- function(libpath) {
   library.dynam.unload("haven", libpath)
}
