remote_sha <- function(...){
  getFromNamespace('remote_sha', 'devtools')(...)
}

github_remote <- function(...){
  getFromNamespace('github_remote', 'devtools')(...)
}

parse_git_repo <- function(...){
  getFromNamespace('parse_git_repo', 'devtools')(...)
}
