#ifndef VCTRS_RUNS_H
#define VCTRS_RUNS_H

#include "vctrs-core.h"

r_obj* vec_identify_runs(r_obj* x);

#endif
