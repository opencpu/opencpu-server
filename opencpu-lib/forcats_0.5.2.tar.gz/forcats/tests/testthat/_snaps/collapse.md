# group_other is deprecated

    Code
      f2 <- fct_collapse(f1, x1 = c("a", "d"), x2 = "c", group_other = TRUE)
    Condition
      Warning:
      The `group_other` argument of `fct_collapse()` is deprecated as of forcats 0.5.0.
      Please use the `other_level` argument instead.

