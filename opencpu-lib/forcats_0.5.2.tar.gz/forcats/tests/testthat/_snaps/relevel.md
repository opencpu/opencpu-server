# warns about unknown levels

    Code
      f2 <- fct_relevel(f1, "d")
    Condition
      Warning:
      1 unknown level in `f`: d

