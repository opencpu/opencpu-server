# error when levels are missing

    Code
      fct_match(f, "d")
    Condition
      Error in `fct_match()`:
      ! All `lvls` must be present in `f`.
      i Missing levels: "d"

