#ifndef RLANG_INTERNAL_GLOBALS_H
#define RLANG_INTERNAL_GLOBALS_H

#include <rlang.h>


struct syms {
  r_obj* arg_nm;
};

extern struct syms syms;


#endif
