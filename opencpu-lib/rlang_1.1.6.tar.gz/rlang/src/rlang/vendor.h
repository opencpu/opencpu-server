// IWYU pragma: private; include "rlang.h"

#ifndef RLANG_VENDOR_H
#define RLANG_VENDOR_H


extern uint64_t (*r_xxh3_64bits)(const void*, size_t);


#endif
