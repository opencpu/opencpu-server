The files in this directory are vendored from fast_float
git tag `v3.4.0`.

See https://github.com/fastfloat/fast_float

Changes:
- enclosed in `arrow_vendored` namespace.
