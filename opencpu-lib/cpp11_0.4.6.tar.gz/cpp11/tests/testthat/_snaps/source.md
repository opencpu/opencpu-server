# cpp_source fails informatively for nonexistent file

    Code
      cpp_source(i_do_not_exist)
    Error <simpleError>
      Can't find `file` at this path:
      {NON_EXISTENT_FILEPATH}

