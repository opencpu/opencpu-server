#' @keywords internal
#' @aliases vroom-package
"_PACKAGE"

## usethis namespace: start
#' @importFrom lifecycle deprecate_warn
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
