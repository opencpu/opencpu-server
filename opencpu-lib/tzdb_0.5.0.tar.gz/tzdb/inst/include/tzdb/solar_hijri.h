#ifndef TZDB_SOLAR_HIJRI_H
#define TZDB_SOLAR_HIJRI_H

#include <tzdb/defines.h>
#include <date/solar_hijri.h>

#endif
