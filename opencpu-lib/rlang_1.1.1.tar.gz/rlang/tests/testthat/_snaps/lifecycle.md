# can supply bullets

    Code
      deprecate_warn(c("foo", i = "bar"))
    Warning <lifecycle_warning_deprecated>
      foo
      i bar
      This warning is displayed once every 8 hours.

