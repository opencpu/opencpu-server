stack.info <- function() .Call(C_stackinfo)
