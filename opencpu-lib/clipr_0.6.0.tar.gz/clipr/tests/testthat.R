library(testthat)
library(clipr)

test_check("clipr")
