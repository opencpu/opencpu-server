# option show.error.messages works as expected

    Code
      brew("error.brew", envir = new.env(), extendedErrorReport = TRUE)
    Output
      Error Test
    Message <simpleMessage>
      STACK DEPTH AE: 52

