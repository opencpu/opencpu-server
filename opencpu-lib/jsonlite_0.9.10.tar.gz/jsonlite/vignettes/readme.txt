Vignettes that depend on internet access have been precompiled:

library(knitr)
knitr("vignettes/json-apis.Rmd.orig", "vignettes/json-apis.Rmd")
knitr("vignettes/json-paging.Rmd.orig", "vignettes/json-paging.Rmd")
