
## @knitr echo=FALSE
x=paste('\\Sexpr', '{', 'z}', sep = '')


