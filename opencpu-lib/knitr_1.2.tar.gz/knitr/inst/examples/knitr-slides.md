See https://github.com/yihui/knitr-examples/blob/master/009-slides.Rmd
