library(testthat)
library(knitr)

test_package("knitr")
