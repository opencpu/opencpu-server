static r_obj* vec_interleave_indices(r_ssize n, r_ssize size);
