static
r_ssize vec_size_opts(r_obj* x, const struct vec_error_opts* opts);

static
r_ssize vec_raw_size(r_obj* x);

static
r_obj* list_sizes(r_obj* x, const struct vec_error_opts* err);

static
bool list_all_size(r_obj* xs, r_ssize size);
