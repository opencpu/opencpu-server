#ifndef VCTRS_SLICE_CHOP_H
#define VCTRS_SLICE_CHOP_H

#include "vctrs-core.h"


r_obj* vec_as_indices(r_obj* indices, r_ssize n, r_obj* names);


#endif
