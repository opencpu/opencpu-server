# error report produces stack trace (or not)

    Code
      brew("error.brew", envir = new.env())
    Output
      Error in fnc() : could not find function "fnc"

