# option show.error.messages works as expected

    Code
      brew("error.brew", envir = new.env(), extendedErrorReport = TRUE)

