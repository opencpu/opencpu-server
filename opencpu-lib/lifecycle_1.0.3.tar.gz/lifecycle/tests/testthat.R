library(testthat)
library(lifecycle)

test_check("lifecycle")
