# extension types can be created

    `extension_array` must be a ChunkedArray or ExtensionArray
    i Got object of type character

# vctrs extension type works

    `extension_array` must be a ChunkedArray or ExtensionArray
    i Got object of type character

