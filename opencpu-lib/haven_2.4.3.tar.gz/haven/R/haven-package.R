#' @useDynLib haven, .registration = TRUE
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @import vctrs
#' @importFrom tibble tibble
#' @importFrom hms hms
## usethis namespace: end
NULL
