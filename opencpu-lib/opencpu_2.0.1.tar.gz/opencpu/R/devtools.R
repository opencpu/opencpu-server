remote_sha <- getFromNamespace('remote_sha', 'devtools')
github_remote <- getFromNamespace('github_remote', 'devtools')
