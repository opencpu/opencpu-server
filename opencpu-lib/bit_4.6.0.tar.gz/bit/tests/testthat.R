library(testthat)
library(bit)

test_check("bit")
