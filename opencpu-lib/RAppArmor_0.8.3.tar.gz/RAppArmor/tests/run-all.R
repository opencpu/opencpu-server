#This file runs all unit tests on every R CMD check.
#Comment this out to disable.

#library(testthat)
#test_package("RAppArmor")