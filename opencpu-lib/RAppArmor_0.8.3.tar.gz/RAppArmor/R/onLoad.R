.onLoad <-function (lib, pkg)   {
	library.dynam("RAppArmor", pkg, lib)
}