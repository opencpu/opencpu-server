# smoke test

    Code
      pillar(v, width = 15)
    Output
      <pillar>
      <list<int>>
              [1]
              [3]

---

    Code
      pillar(v, width = 30)
    Output
      <pillar>
      <list<ovrrd_s_>>
                    SC

