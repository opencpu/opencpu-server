options(curl_interrupt = TRUE)
cat("This is libcurl version", curl_version()$version, "with", curl_version()$ssl_version, "\n")
