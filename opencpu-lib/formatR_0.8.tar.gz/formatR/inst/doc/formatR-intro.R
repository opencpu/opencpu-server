
## @knitr lyx-doc, eval=FALSE
## system.file('doc', 'formatR.Rmd', package='formatR')




