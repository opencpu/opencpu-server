# formatR

Format R code automatically.

See the package homepage <http://yihui.name/formatR> for more information.

