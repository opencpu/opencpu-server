#ifndef BASE64_H
#define BASE64_H

std::string b64encode(const std::vector<uint8_t>& data);

#endif