
cli_style <- with_options(
  cli.unicode = FALSE,
  cli_box_chars()
)
