### R code from vignette source 'Rcpp-attributes.Rnw'

