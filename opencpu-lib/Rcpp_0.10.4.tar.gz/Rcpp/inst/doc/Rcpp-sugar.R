### R code from vignette source 'Rcpp-sugar.Rnw'

