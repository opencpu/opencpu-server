### R code from vignette source 'Rcpp-modules.Rnw'

