### R code from vignette source 'Rcpp-extending.Rnw'

