### R code from vignette source 'Rcpp-FAQ.Rnw'

