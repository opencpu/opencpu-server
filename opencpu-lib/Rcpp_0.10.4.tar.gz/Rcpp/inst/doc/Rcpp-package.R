### R code from vignette source 'Rcpp-package.Rnw'

