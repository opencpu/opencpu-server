getrapache <- function(x){
  get(x, "rapache")
}
